
const express = require("express");
const mysql = require("mysql");
//form: 'EECxTScgbQ',findteacher
jj = {
    'button_info[type]': '1',
    'button_info[times]': '10000000',
    'button_info[button_id]': 'liulei',
    'button_info[operation]': 'inner-link',
    form: 'zxzx',
    'form_data[tp]': 'eq',
    'form_data[bt]': 'eqw',
    'form_data[sj]': 'eqw',
    'form_data[bq]': 'eqw',
    'form_data[xq]': 'eqw',
    'form_data[IUlTRulNgl]': 'eqw',
    'form_data[tEKXdAmMAu]': 'qew',
    'form_data[kKbxwLWQUk]': 'qwe',
    'form_data[JullSWzFCx]': '50-60',
    is_transfer_order: '0',
    'event_params_of_form_review_passed[type]': '1',
    'event_params_of_form_review_passed[times]': '10000000',
    'event_params_of_form_review_passed[button_id]': 'liulei',
    'event_params_of_form_review_passed[operation]': ''
};
console.log(jj.form);

function gettime() {
    var date = new Date();
    var year = date.getFullYear();
    var month = date.getMonth()+1;
    var day = date.getDate();
    var hour = date.getHours();
    var minute = date.getMinutes();
    var second = date.getSeconds();
    return(year+'.'+month+'.'+day+' '+hour+':'+minute+':'+second);
}

function writedata(js) {
    var connection = mysql.createConnection({
        host: "localhost", // 数据库服务器的地址
        user: "root", // 账号
        password: "sbll654123", // 密码
        database: "userdata", // 数据库名
    });
    a = gettime();
    connection.connect();
    let addsql = 'INSERT INTO hireteacher(Ename,Enaddress,tel,wechat,bk,teachtime,needmem,detail,money,time) VALUES(?,?,?,?,?,?,?,?,?,?)';
    let addsqlparma = ['1','1','1','1','1','1','1','1','1',a];
    connection.query(addsql,addsqlparma,(error, results)=> {
            if (error == null) {
                console.log(results); // 返回结果是一个对象
                console.log(results.affectedRows); // 受影响的行数，如果大于0，说明新增成功
                console.log(results.insertId); // 插入的这条数据的id
            }else{
                console.log(error)
            }

        }
    );

    connection.end();
}



function say() {
    var myDate = new Date();
    myDate.toLocaleDateString(); //获取当前日期
    console.log(myDate);
    var mytime=myDate.toLocaleTimeString(); //获取当前时间
    console.log(mytime);
}

id = 'button_info[button_id]';


writedata(jj);
// var connection = mysql.createConnection({
//     host: "localhost", // 数据库服务器的地址
//     user: "root", // 账号
//     password: "sbll654123", // 密码
//     database: "userdata", // 数据库名
// });
// // connection.connect((error) =>{
// //     if(err) throw err;
// //     console.log('connected successed');
// // });
// connection.connect()