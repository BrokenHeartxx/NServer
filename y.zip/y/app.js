const http = require( "http" );
const querystring = require("querystring");
const mysql = require("mysql");
let aa = "";
let app = http.createServer( function ( req, res ) {
    if( req.url !== "favicon.ico" ){
        try{
            let reqData = "";
            req.on( "data", function ( dataChunk ) {
                reqData += decodeURIComponent( dataChunk );

            } );

            req.on( "end", function () {
                res.setHeader( "Content-Type", "application/json;charset=utf-8" );
                res.setHeader( "Access-Control-Allow-Origin", "*" );

                res.write( reqData );
                aa = reqData;
                if (aa.trim()!== ""){
                    var bb = JSON.stringify(querystring.parse(aa));
                    var bj = JSON.parse(bb);
                    if(bj.hasOwnProperty("button_info[type]")){
                        if(bj.form==='zx'){
                            writedatazx(bj);
                        }else if (bj.form==='EECxTScgbQ'){
                            writedataEQ(bj);
                        }else {
                            writedatazxzx(bj);
                        }
                    }
                }else {
                    // console.log('12')
                }
                res.end();
            } )
        }catch( e ){
            console.log( e );
        }
    }
} );

function gettime() {
    var date = new Date();
    var year = date.getFullYear();
    var month = date.getMonth()+1;
    var day = date.getDate();
    var hour = date.getHours();
    var minute = date.getMinutes();
    var second = date.getSeconds();
    return(year+'.'+month+'.'+day+' '+hour+':'+minute+':'+second);
}

function writedatazxzx(jj) {
    var connection = mysql.createConnection({
        host: "localhost", // 数据库服务器的地址
        user: "root", // 账号
        password: "sbll654123", // 密码
        database: "userdata", // 数据库名
    });
    var a = gettime();
    connection.connect();
    if(jj['form_data[tp]']===' '&&jj['form_data[bt]']===' '&&jj['form_data[sj]']===' '&&jj['form_data[bq]']===' '&&jj['form_data[xq]']===' '&&jj['form_data[IUlTRulNgl]']===' '&&jj['form_data[tEKXdAmMAu]']===' '){
        console.log('fake user');
        connection.end();
    }
    else if(jj['form_data[sj]'].length===11){
        let addsql = 'INSERT INTO hireteacher(Ename,Enaddress,tel,wechat,bk,teachtime,needmem,detail,money,time) VALUES(?,?,?,?,?,?,?,?,?,?)';
        let addsqlparma = [jj['form_data[tp]'],jj['form_data[bt]'],jj['form_data[sj]'],jj['form_data[bq]'],jj['form_data[xq]'],jj['form_data[IUlTRulNgl]'],jj['form_data[tEKXdAmMAu]'],jj['form_data[kKbxwLWQUk]'],jj['form_data[JullSWzFCx]'],a];
        connection.query(addsql,addsqlparma,(error, results)=> {
                if (error == null) {
                    console.log('some company findteacher at '+a);
                    // console.log(results);
                    // console.log(results.affectedRows);
                    // console.log(results.insertId);
                }else{
                    console.log(error);
                }

            }
        );
        // console.log('some company findteacher at'+a);
        connection.end();
    }else {
        console.log('fake user')
    }

}
function writedataEQ(jj) {
    var connection = mysql.createConnection({
        host: "localhost",
        user: "root",
        password: "sbll654123",
        database: "userdata",
    });
    var a = gettime();
    connection.connect();
    if(jj['form_data[wPWOTjlJhU]']===' '&&jj['form_data[QXllPOcRME]']===' '&&jj['form_data[NIEnrLDQji]']===' '&&jj['form_data[tvSOtcXlea]']===' '&&jj['form_data[hQGYkigiAo]']===' '&&jj['form_data[LfNqvnxINS]']===' '){
        console.log('fake user');
        connection.end();
    }else if(jj['form_data[NIEnrLDQji]'].length===11){
        let addsql = 'INSERT INTO findteacher(Ename,Enaddress,tel,wechat,bk,teachtime,detail,money,time) VALUES(?,?,?,?,?,?,?,?,?)';
        let addsqlparma = [jj['form_data[wPWOTjlJhU]'],jj['form_data[QXllPOcRME]'],jj['form_data[NIEnrLDQji]'],jj['form_data[tvSOtcXlea]'],jj['form_data[hQGYkigiAo]'],jj['form_data[LfNqvnxINS]'],jj['form_data[qzRJCeyNyW]'],jj['form_data[riAShfhSnb]'],a];
        connection.query(addsql,addsqlparma,(error, results)=> {
                if (error == null) {
                    console.log('somebody findteacher at '+a);
                    // console.log(results); // 返回结果是一个对象
                    // console.log(results.affectedRows); // 受影响的行数，如果大于0，说明新增成功
                    // console.log(results.insertId); // 插入的这条数据的id
                }else{
                    console.log(error)
                }

            }
        );
        connection.end();
    }else {
        console.log('fake user')
    }

}
function writedatazx(jj) {
    var connection = mysql.createConnection({
        host: "localhost", // 数据库服务器的地址
        user: "root", // 账号
        password: "sbll654123", // 密码
        database: "userdata", // 数据库名
    });
    var a = gettime();
    connection.connect();
    if(jj['form_data[tp]']===' '&&jj['form_data[bt]']===' '&&jj['form_data[sj]']===' '&&jj['form_data[bq]']===' '&&jj['form_data[xq]']===' '&&jj['form_data[tpb]']===' '){
        console.log('fake user');
        connection.end();
    } else if(jj['form_data[bt]'].length===11) {
        let addsql = 'INSERT INTO accteacher(Ename,tel,wechat,major,teachtime,profession,detail,money,time) VALUES(?,?,?,?,?,?,?,?,?)';
        let addsqlparma =[jj['form_data[tp]'],jj['form_data[bt]'],jj['form_data[sj]'],jj['form_data[bq]'],jj['form_data[xq]'],jj['form_data[tpb]'],jj['form_data[tpc]'],jj['form_data[jj]'],a];
        connection.query(addsql,addsqlparma,(error, results)=> {
                if (error == null) {
                    console.log('someone want to be a teacher at '+a);
                    // console.log(results); // 返回结果是一个对象
                    // console.log(results.affectedRows); // 受影响的行数，如果大于0，说明新增成功
                    // console.log(results.insertId); // 插入的这条数据的id
                }else{
                    console.log(error)
                }

            }
        );
        connection.end();
    }else {
        console.log('fake user')
    }


}
app.listen( 80, ()=>{ console.log( "service is running at port 80." ); } );

